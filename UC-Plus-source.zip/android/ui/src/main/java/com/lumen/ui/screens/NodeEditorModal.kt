package com.lumen.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/**
 * Full node editor supporting all protocols from the desktop app:
 * VLESS / VMess / Trojan / Shadowsocks / Hysteria / Hysteria2 / TUIC / WireGuard /
 * AmneziaWG / OpenVPN / SOCKS / HTTP.
 */
@Composable
fun NodeEditorModal(
    initial: NodeDraft,
    onDismiss: () -> Unit,
    onSave: (NodeDraft) -> Unit
) {
    var draft by remember(initial) { mutableStateOf(initial) }
    val s = LocalStrings.current
    val tick = rememberHapticTick()

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.94f)
                .padding(horizontal = 10.dp)
                .imePadding(),
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(Modifier.padding(16.dp)) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        if (initial.id == null) s.addNode else s.editNode,
                        style = MaterialTheme.typography.headlineMedium
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Filled.Close, contentDescription = s.close, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Column(
                    Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                ) {
                    Field(s.nodeName, draft.name) { draft = draft.copy(name = it) }
                    LumenDropdown(
                        label = s.protocolField,
                        options = SUPPORTED_PROTOCOLS,
                        selected = draft.protocol,
                        onSelected = { draft = draft.copy(protocol = it) },
                        optionLabel = { protocolLabel(it) }
                    )
                    Spacer(Modifier.height(8.dp))
                    when (draft.protocol) {
                        "auto" -> Text(
                            s.autoNodeDescriptionLabel,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        "openvpn" -> OpenVpnFields(draft = draft, onChange = { draft = it })
                        "masque" -> MasqueFields(draft = draft, onChange = { draft = it })
                        "wireguard", "awg" -> WireGuardFields(
                            draft = draft,
                            isAwg = draft.protocol == "awg",
                            onChange = { draft = it }
                        )
                        else -> UriProtocolFields(draft = draft, onChange = { draft = it })
                    }
                    Spacer(Modifier.height(12.dp))
                }
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) { Text(s.cancel) }
                    Spacer(Modifier.width(8.dp))
                    com.lumen.ui.components.ExpressiveAction(
                        label = s.saveAction,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            // A saved node is the "server added" moment the user feels.
                            tick(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
                            onSave(draft)
                        },
                        enabled = isDraftValid(draft)
                    )
                }
            }
        }
    }
}

private fun protocolLabel(p: String): String = when (p) {
    "vless" -> "VLESS"
    "vmess" -> "VMess"
    "trojan" -> "Trojan"
    "ss" -> "Shadowsocks"
    "hysteria" -> "Hysteria"
    "hysteria2" -> "Hysteria2"
    "tuic" -> "TUIC v5"
    "wireguard" -> "WireGuard"
    "awg" -> "AmneziaWG"
    "masque" -> "MASQUE"
    "openvpn" -> "OpenVPN"
    "socks" -> "SOCKS5"
    "http" -> "HTTP"
    "auto" -> "Auto (url-test)"
    else -> p
}

private fun isDraftValid(d: NodeDraft): Boolean = when (d.protocol) {
    "auto" -> d.name.isNotBlank()
    // The MASQUE link carries a profile id instead of a host:port pair.
    "masque" -> d.server.isNotBlank()
    "openvpn" -> d.server.isNotBlank() && d.port.toIntOrNull() != null && d.ovpnCa.isNotBlank() &&
        !openVpnCredentialsMissing(d)
    else -> d.server.isNotBlank() && d.port.toIntOrNull() != null
}

/**
 * True when the profile explicitly asks for username/password authentication.
 * A server may intentionally accept a client without a certificate, so the absence
 * of <cert>/<key> alone is not proof that credentials are required.
 */
fun openVpnRequiresCredentials(d: NodeDraft): Boolean {
    if (d.protocol != "openvpn") return false
    val declared = d.rawConfig.lineSequence().any { line ->
        val token = line.trim().trimStart('-').lowercase()
        token == "auth-user-pass" || token == "<auth-user-pass>" ||
            token.startsWith("auth-user-pass ") || token.startsWith("auth-user-pass\t")
    }
    return declared
}

/**
 * The node would be saved looking ready while the core has nothing to authenticate with:
 * the tunnel then fails with an obscure handshake error instead of a missing password.
 */
fun openVpnCredentialsMissing(d: NodeDraft): Boolean =
    openVpnRequiresCredentials(d) && (d.ovpnUsername.isBlank() || d.ovpnPassword.isBlank())

/**
 * An encrypted private key ("Proc-Type: 4,ENCRYPTED" for traditional PEM keys,
 * "BEGIN ENCRYPTED PRIVATE KEY" for PKCS#8) cannot be loaded without its
 * passphrase: OpenVPN would ask for it interactively, which is impossible here.
 */
fun openVpnKeyIsEncrypted(key: String): Boolean {
    val text = key.uppercase()
    return text.contains("ENCRYPTED PRIVATE KEY") ||
        (text.contains("PROC-TYPE:") && text.contains("ENCRYPTED"))
}

/** The private key needs a passphrase and the editor field is still empty. */
fun openVpnKeyPasswordMissing(d: NodeDraft): Boolean =
    d.protocol == "openvpn" && openVpnKeyIsEncrypted(d.ovpnKey) && d.ovpnKeyPassword.isBlank()

@Composable
private fun Field(
    label: String,
    value: String,
    keyboardType: KeyboardType = KeyboardType.Text,
    singleLine: Boolean = true,
    minLines: Int = 1,
    secret: Boolean = false,
    onChange: (String) -> Unit
) {
    ExpressiveTextField(
            shape = MaterialTheme.shapes.large,
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = singleLine,
        minLines = minLines,
        keyboardOptions = KeyboardOptions(keyboardType = if (secret) KeyboardType.Password else keyboardType),
        visualTransformation = if (secret) androidx.compose.ui.text.input.PasswordVisualTransformation()
            else androidx.compose.ui.text.input.VisualTransformation.None,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    )
}

@Composable
private fun ServerPortRow(draft: NodeDraft, onChange: (NodeDraft) -> Unit) {
    val s = LocalStrings.current
    Row(Modifier.fillMaxWidth()) {
        ExpressiveTextField(
            shape = MaterialTheme.shapes.large,
            value = draft.server,
            onValueChange = { onChange(draft.copy(server = it)) },
            label = { Text(s.serverLabel) },
            singleLine = true,
            modifier = Modifier
                .weight(0.65f)
                .padding(vertical = 4.dp)
        )
        Spacer(Modifier.width(8.dp))
        ExpressiveTextField(
            shape = MaterialTheme.shapes.large,
            value = draft.port,
            onValueChange = { onChange(draft.copy(port = it)) },
            label = { Text(s.portLabel) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier
                .weight(0.35f)
                .padding(vertical = 4.dp)
        )
    }
}

/** Inline blocker: the field above is missing something the node cannot be saved without. */
@Composable
private fun EditorWarning(text: String) {
    val shape = RoundedCornerShape(12.dp)
    val accent = MaterialTheme.colorScheme.error
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .clip(shape)
            .background(accent.copy(alpha = 0.12f))
            .border(1.dp, accent.copy(alpha = 0.55f), shape)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            Icons.Filled.Warning,
            contentDescription = null,
            tint = accent,
            modifier = Modifier.size(18.dp)
        )
        Spacer(Modifier.width(10.dp))
        Text(
            text,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun ToggleField(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        LumenSwitch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun TransportFields(draft: NodeDraft, onChange: (NodeDraft) -> Unit) {
    val s = LocalStrings.current
    LumenDropdown(
        label = s.transportLabel,
        options = NETWORK_TRANSPORTS,
        selected = draft.network,
        onSelected = {
            onChange(
                draft.copy(
                    network = it,
                    // The exact extended core only registers QUIC as a V2Ray
                    // transport inside a TLS/Reality connection.
                    security = if (it == "quic" && draft.security == "none") "tls" else draft.security
                )
            )
        }
    )
    Spacer(Modifier.height(4.dp))
    if (draft.network in listOf("ws", "xhttp", "http")) {
        Field(s.pathLabel, draft.path) { onChange(draft.copy(path = it)) }
        Field(s.hostHeaderLabel, draft.host) { onChange(draft.copy(host = it)) }
    }
    if (draft.network == "grpc") {
        Field(s.grpcServiceNameLabel, draft.serviceName) { onChange(draft.copy(serviceName = it)) }
    }
}

@Composable
private fun SecurityFields(
    draft: NodeDraft,
    onChange: (NodeDraft) -> Unit,
    allowReality: Boolean = true
) {
    val s = LocalStrings.current
    val options = if (allowReality) SECURITY_OPTIONS else listOf("none", "tls")
    LumenDropdown(
        label = s.securityLabel,
        options = options,
        selected = draft.security,
        onSelected = { onChange(draft.copy(security = it)) }
    )
    Spacer(Modifier.height(4.dp))
    if (draft.security != "none") {
        Field(s.sniLabel, draft.sni) { onChange(draft.copy(sni = it)) }
        Field(s.alpnLabel, draft.alpn) { onChange(draft.copy(alpn = it)) }
        Field(s.utlsFingerprintLabel, draft.fingerprint) { onChange(draft.copy(fingerprint = it)) }
        Field(s.certificateSha256Label, draft.certificateSha256) {
            onChange(draft.copy(certificateSha256 = it))
        }
        ToggleField(s.allowInsecureTlsLabel, draft.insecure) { onChange(draft.copy(insecure = it)) }
    }
    if (draft.security == "reality") {
        Field(s.realityPublicKeyLabel, draft.publicKey) { onChange(draft.copy(publicKey = it)) }
        Field(s.realityShortIdLabel, draft.shortId) { onChange(draft.copy(shortId = it)) }
    }
}

@Composable
private fun UriProtocolFields(draft: NodeDraft, onChange: (NodeDraft) -> Unit) {
    val s = LocalStrings.current
    ServerPortRow(draft, onChange)
    when (draft.protocol) {
        "vless" -> {
            Field(s.uuidLabel, draft.secret) { onChange(draft.copy(secret = it)) }
            LumenDropdown(
                label = s.flowLabel,
                options = listOf("", "xtls-rprx-vision"),
                selected = draft.flow,
                onSelected = { onChange(draft.copy(flow = it)) },
                optionLabel = { it.ifEmpty { s.noneOption } }
            )
            Spacer(Modifier.height(4.dp))
            TransportFields(draft, onChange)
            SecurityFields(draft, onChange)
        }
        "vmess" -> {
            Field(s.uuidLabel, draft.secret) { onChange(draft.copy(secret = it)) }
            TransportFields(draft, onChange)
            SecurityFields(draft, onChange, allowReality = false)
        }
        "trojan" -> {
            Field(s.password, draft.secret) { onChange(draft.copy(secret = it)) }
            TransportFields(draft, onChange)
            SecurityFields(draft, onChange)
        }
        "ss" -> {
            LumenDropdown(
                label = s.encryptionMethodLabel,
                options = SS_METHODS,
                selected = draft.method,
                onSelected = { onChange(draft.copy(method = it)) }
            )
            Field(s.password, draft.secret) { onChange(draft.copy(secret = it)) }
        }
        "hysteria", "hysteria2" -> {
            Field(s.passwordAuthLabel, draft.secret) { onChange(draft.copy(secret = it)) }
            Field(s.sniLabel, draft.sni) { onChange(draft.copy(sni = it)) }
            Field(s.certificateSha256Label, draft.certificateSha256) {
                onChange(draft.copy(certificateSha256 = it))
            }
            Field(s.obfsLabel, draft.obfs) { onChange(draft.copy(obfs = it)) }
            Field(s.obfsPasswordLabel, draft.obfsPassword) { onChange(draft.copy(obfsPassword = it)) }
            ToggleField(s.allowInsecureTlsLabel, draft.insecure) { onChange(draft.copy(insecure = it)) }
        }
        "tuic" -> {
            Field(s.uuidPasswordLabel, draft.secret) { onChange(draft.copy(secret = it)) }
            Field(s.sniLabel, draft.sni) { onChange(draft.copy(sni = it)) }
            Field(s.alpnLabel, draft.alpn) { onChange(draft.copy(alpn = it)) }
            Field(s.certificateSha256Label, draft.certificateSha256) {
                onChange(draft.copy(certificateSha256 = it))
            }
            LumenDropdown(
                label = s.congestionControlLabel,
                options = CONGESTION_OPTIONS,
                selected = draft.congestionControl,
                onSelected = { onChange(draft.copy(congestionControl = it)) }
            )
            Spacer(Modifier.height(4.dp))
            ToggleField(s.allowInsecureTlsLabel, draft.insecure) { onChange(draft.copy(insecure = it)) }
        }
        "socks", "http" -> {
            Field(s.userPasswordOptionalLabel, draft.secret) { onChange(draft.copy(secret = it)) }
        }
    }
}

/**
 * MASQUE nodes are addressed by a WARP profile id and an auth token, so they
 * have no host/port row.
 */
@Composable
private fun MasqueFields(draft: NodeDraft, onChange: (NodeDraft) -> Unit) {
    val s = LocalStrings.current
    Field(s.masqueProfileIdLabel, draft.server) { onChange(draft.copy(server = it)) }
    Field(s.masqueAuthTokenLabel, draft.secret) { onChange(draft.copy(secret = it)) }
    Field(s.sniLabel, draft.sni) { onChange(draft.copy(sni = it)) }
    ToggleField(s.allowInsecureTlsLabel, draft.insecure) { onChange(draft.copy(insecure = it)) }
}

@Composable
private fun WireGuardFields(
    draft: NodeDraft,
    isAwg: Boolean,
    onChange: (NodeDraft) -> Unit
) {
    val s = LocalStrings.current
    ServerPortRow(draft, onChange)
    Field(s.privateKeyLabel, draft.secret) { onChange(draft.copy(secret = it)) }
    Field(s.peerPublicKeyLabel, draft.publicKey) { onChange(draft.copy(publicKey = it)) }
    Field(s.wgAddressLabel, draft.address) { onChange(draft.copy(address = it)) }
    Field(s.presharedKeyLabel, draft.presharedKey) { onChange(draft.copy(presharedKey = it)) }
    Field(s.allowedIpsLabel, draft.allowedIps) { onChange(draft.copy(allowedIps = it)) }
    Field(s.reservedLabel, draft.reserved) { onChange(draft.copy(reserved = it)) }
    Field(s.wgMtuLabel, draft.mtu, keyboardType = KeyboardType.Number) { onChange(draft.copy(mtu = it)) }
    Field(s.wgDnsLabel, draft.dns) { onChange(draft.copy(dns = it)) }
    Field(s.wgKeepaliveLabel, draft.persistentKeepalive, keyboardType = KeyboardType.Number) {
        onChange(draft.copy(persistentKeepalive = it))
    }
    if (!isAwg) {
        // wg -> awg with the Amnezia defaults, same as desktop Lumen / wgtunnel.
        OutlinedButton(
            onClick = { onChange(amneziaCompatible(draft)) },
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
        ) {
            Text(s.amneziaCompatible)
        }
        Text(
            s.amneziaCompatibleDesc,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
    if (isAwg) {
        // awg -> wg: drop the obfuscation parameters and go back to plain WireGuard.
        OutlinedButton(
            onClick = { onChange(plainWireGuard(draft)) },
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
        ) {
            Text(s.disableAmnezia)
        }
        Text(
            s.disableAmneziaDesc,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp)
        )
        SectionHeader(s.awgJunkParamsLabel)
        Row(Modifier.fillMaxWidth()) {
            ExpressiveTextField(
            shape = MaterialTheme.shapes.large,
                value = draft.jc,
                onValueChange = { onChange(draft.copy(jc = it)) },
                label = { Text("Jc") },
                singleLine = true,
                modifier = Modifier.weight(1f).padding(vertical = 4.dp)
            )
            Spacer(Modifier.width(6.dp))
            ExpressiveTextField(
            shape = MaterialTheme.shapes.large,
                value = draft.jmin,
                onValueChange = { onChange(draft.copy(jmin = it)) },
                label = { Text("Jmin") },
                singleLine = true,
                modifier = Modifier.weight(1f).padding(vertical = 4.dp)
            )
            Spacer(Modifier.width(6.dp))
            ExpressiveTextField(
            shape = MaterialTheme.shapes.large,
                value = draft.jmax,
                onValueChange = { onChange(draft.copy(jmax = it)) },
                label = { Text("Jmax") },
                singleLine = true,
                modifier = Modifier.weight(1f).padding(vertical = 4.dp)
            )
        }
        Row(Modifier.fillMaxWidth()) {
            ExpressiveTextField(
            shape = MaterialTheme.shapes.large,
                value = draft.s1,
                onValueChange = { onChange(draft.copy(s1 = it)) },
                label = { Text("S1") },
                singleLine = true,
                modifier = Modifier.weight(1f).padding(vertical = 4.dp)
            )
            Spacer(Modifier.width(6.dp))
            ExpressiveTextField(
            shape = MaterialTheme.shapes.large,
                value = draft.s2,
                onValueChange = { onChange(draft.copy(s2 = it)) },
                label = { Text("S2") },
                singleLine = true,
                modifier = Modifier.weight(1f).padding(vertical = 4.dp)
            )
            Spacer(Modifier.width(6.dp))
            ExpressiveTextField(
            shape = MaterialTheme.shapes.large,
                value = draft.s3,
                onValueChange = { onChange(draft.copy(s3 = it)) },
                label = { Text("S3") },
                singleLine = true,
                modifier = Modifier.weight(1f).padding(vertical = 4.dp)
            )
            Spacer(Modifier.width(6.dp))
            ExpressiveTextField(
            shape = MaterialTheme.shapes.large,
                value = draft.s4,
                onValueChange = { onChange(draft.copy(s4 = it)) },
                label = { Text("S4") },
                singleLine = true,
                modifier = Modifier.weight(1f).padding(vertical = 4.dp)
            )
        }
        SectionHeader(s.awgHeadersLabel)
        Row(Modifier.fillMaxWidth()) {
            ExpressiveTextField(
            shape = MaterialTheme.shapes.large,
                value = draft.h1,
                onValueChange = { onChange(draft.copy(h1 = it)) },
                label = { Text("H1") },
                singleLine = true,
                modifier = Modifier.weight(1f).padding(vertical = 4.dp)
            )
            Spacer(Modifier.width(6.dp))
            ExpressiveTextField(
            shape = MaterialTheme.shapes.large,
                value = draft.h2,
                onValueChange = { onChange(draft.copy(h2 = it)) },
                label = { Text("H2") },
                singleLine = true,
                modifier = Modifier.weight(1f).padding(vertical = 4.dp)
            )
            Spacer(Modifier.width(6.dp))
            ExpressiveTextField(
            shape = MaterialTheme.shapes.large,
                value = draft.h3,
                onValueChange = { onChange(draft.copy(h3 = it)) },
                label = { Text("H3") },
                singleLine = true,
                modifier = Modifier.weight(1f).padding(vertical = 4.dp)
            )
            Spacer(Modifier.width(6.dp))
            ExpressiveTextField(
            shape = MaterialTheme.shapes.large,
                value = draft.h4,
                onValueChange = { onChange(draft.copy(h4 = it)) },
                label = { Text("H4") },
                singleLine = true,
                modifier = Modifier.weight(1f).padding(vertical = 4.dp)
            )
        }
        SectionHeader("AWG 3.x")
        Field(InterfaceText.HEADER_KEY.inLanguage(s.localeCode), draft.headerProtectionKey) {
            onChange(draft.copy(headerProtectionKey = it))
        }
        Field(InterfaceText.PADDING.inLanguage(s.localeCode), draft.contentPaddingAddition) {
            onChange(draft.copy(contentPaddingAddition = it))
        }
        Field(InterfaceText.REKEY_AFTER.inLanguage(s.localeCode), draft.rekeyAfterTime) { onChange(draft.copy(rekeyAfterTime = it)) }
        Field(InterfaceText.REKEY_TIMEOUT.inLanguage(s.localeCode), draft.rekeyTimeout) { onChange(draft.copy(rekeyTimeout = it)) }
        Field(InterfaceText.REJECT_AFTER.inLanguage(s.localeCode), draft.rejectAfterTime) { onChange(draft.copy(rejectAfterTime = it)) }
        Field(InterfaceText.KEEPALIVE_TIMEOUT.inLanguage(s.localeCode), draft.keepaliveTimeout) { onChange(draft.copy(keepaliveTimeout = it)) }
        Field(InterfaceText.HANDSHAKE_ATTEMPTS.inLanguage(s.localeCode), draft.maxHandshakeAttempts) {
            onChange(draft.copy(maxHandshakeAttempts = it))
        }
    }
}

/**
 * Structured OpenVPN editor, same field set as the desktop Lumen node editor.
 */
@Composable
private fun OpenVpnFields(draft: NodeDraft, onChange: (NodeDraft) -> Unit) {
    val s = LocalStrings.current

    ServerPortRow(draft, onChange)
    LumenDropdown(
        label = s.protocolField,
        options = OPENVPN_PROTOCOLS,
        selected = draft.ovpnProto.ifBlank { "udp" },
        onSelected = { onChange(draft.copy(ovpnProto = it)) }
    )
    Spacer(Modifier.height(4.dp))
    Field(InterfaceText.REMOTES.inLanguage(s.localeCode), draft.ovpnExtraRemotes, singleLine = false, minLines = 2) {
        onChange(draft.copy(ovpnExtraRemotes = it))
    }

    SectionHeader(InterfaceText.ENCRYPTION.inLanguage(s.localeCode))
    LumenDropdown(
        label = InterfaceText.CIPHER.inLanguage(s.localeCode),
        options = OPENVPN_CIPHERS,
        selected = draft.ovpnCipher,
        onSelected = { onChange(draft.copy(ovpnCipher = it)) },
        optionLabel = { it.ifEmpty { s.noneOption } }
    )
    Spacer(Modifier.height(4.dp))
    LumenDropdown(
        label = InterfaceText.DIGEST.inLanguage(s.localeCode),
        options = OPENVPN_AUTH_DIGESTS,
        selected = draft.ovpnAuth,
        onSelected = { onChange(draft.copy(ovpnAuth = it)) },
        optionLabel = { it.ifEmpty { s.noneOption } }
    )
    Spacer(Modifier.height(4.dp))

    SectionHeader(InterfaceText.CREDENTIALS.inLanguage(s.localeCode))
    val credentialsRequired = openVpnRequiresCredentials(draft)
    Field(s.socks5Login, draft.ovpnUsername) { onChange(draft.copy(ovpnUsername = it)) }
    Field(s.socks5PasswordLabel, draft.ovpnPassword, secret = true) { onChange(draft.copy(ovpnPassword = it)) }
    if (credentialsRequired && openVpnCredentialsMissing(draft)) {
        EditorWarning(s.ovpnCredentialsRequired)
    } else if (!credentialsRequired) {
        Text(
            s.ovpnCertificateOnlyHint,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }

    SectionHeader(InterfaceText.CERTIFICATES.inLanguage(s.localeCode))
    Field(InterfaceText.CA.inLanguage(s.localeCode), draft.ovpnCa, singleLine = false, minLines = 4) { onChange(draft.copy(ovpnCa = it)) }
    Field(InterfaceText.CLIENT_CERT.inLanguage(s.localeCode), draft.ovpnCert, singleLine = false, minLines = 3) { onChange(draft.copy(ovpnCert = it)) }
    Field(s.privateKeyLabel, draft.ovpnKey, singleLine = false, minLines = 3) { onChange(draft.copy(ovpnKey = it)) }
    // Encrypted private keys ("Proc-Type: 4,ENCRYPTED" / PKCS#8 ENCRYPTED) cannot be
    // used without their passphrase; OpenVPN would prompt for it interactively.
    Field(s.ovpnKeyPasswordLabel, draft.ovpnKeyPassword, secret = true) { onChange(draft.copy(ovpnKeyPassword = it)) }
    if (openVpnKeyPasswordMissing(draft)) {
        EditorWarning(s.ovpnKeyPasswordRequired)
    }
    Field(InterfaceText.TLS_CRYPT.inLanguage(s.localeCode), draft.ovpnTlsCrypt, singleLine = false, minLines = 3) { onChange(draft.copy(ovpnTlsCrypt = it)) }
    ToggleField("tls-crypt-v2", draft.ovpnTlsCryptV2) { onChange(draft.copy(ovpnTlsCryptV2 = it)) }
    Field(InterfaceText.TLS_AUTH.inLanguage(s.localeCode), draft.ovpnTlsAuth, singleLine = false, minLines = 3) { onChange(draft.copy(ovpnTlsAuth = it)) }
    LumenDropdown(
        label = InterfaceText.KEY_DIRECTION.inLanguage(s.localeCode),
        options = OPENVPN_KEY_DIRECTIONS,
        selected = draft.ovpnKeyDirection,
        onSelected = { onChange(draft.copy(ovpnKeyDirection = it)) },
        optionLabel = { it.ifEmpty { s.noneOption } }
    )
    Spacer(Modifier.height(4.dp))
    Field(InterfaceText.TLS_SUITES.inLanguage(s.localeCode), draft.ovpnTlsCipherSuites) { onChange(draft.copy(ovpnTlsCipherSuites = it)) }
    Field(InterfaceText.X509_NAME.inLanguage(s.localeCode), draft.ovpnVerifyX509Name) { onChange(draft.copy(ovpnVerifyX509Name = it)) }
    LumenDropdown(
        label = InterfaceText.X509_MODE.inLanguage(s.localeCode),
        options = OPENVPN_X509_MODES,
        selected = draft.ovpnVerifyX509Mode,
        onSelected = { onChange(draft.copy(ovpnVerifyX509Mode = it)) },
        optionLabel = { when (it) {
            "name" -> InterfaceText.X509_EXACT.inLanguage(s.localeCode)
            "name-prefix" -> InterfaceText.X509_PREFIX.inLanguage(s.localeCode)
            "name-suffix" -> InterfaceText.X509_SUFFIX.inLanguage(s.localeCode)
            else -> s.noneOption
        } }
    )
    Spacer(Modifier.height(4.dp))

    SectionHeader(s.connection)
    Row(Modifier.fillMaxWidth()) {
        ExpressiveTextField(
            shape = MaterialTheme.shapes.large,
            value = draft.ovpnReconnectDelay,
            onValueChange = { onChange(draft.copy(ovpnReconnectDelay = it)) },
            label = { Text(InterfaceText.RECONNECT.inLanguage(s.localeCode)) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f).padding(vertical = 4.dp)
        )
        Spacer(Modifier.width(6.dp))
        ExpressiveTextField(
            shape = MaterialTheme.shapes.large,
            value = draft.ovpnPingInterval,
            onValueChange = { onChange(draft.copy(ovpnPingInterval = it)) },
            label = { Text(InterfaceText.PING_INTERVAL.inLanguage(s.localeCode)) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f).padding(vertical = 4.dp)
        )
        Spacer(Modifier.width(6.dp))
        ExpressiveTextField(
            shape = MaterialTheme.shapes.large,
            value = draft.ovpnPingRestart,
            onValueChange = { onChange(draft.copy(ovpnPingRestart = it)) },
            label = { Text(InterfaceText.PING_RESTART.inLanguage(s.localeCode)) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f).padding(vertical = 4.dp)
        )
    }
    Field(InterfaceText.DNS_SERVERS.inLanguage(s.localeCode), draft.ovpnDns, singleLine = false, minLines = 2) {
        onChange(draft.copy(ovpnDns = it))
    }

    SectionHeader(s.useProxyLabel)
    LumenDropdown(
        label = s.useProxyLabel,
        options = OPENVPN_PROXY_TYPES,
        selected = draft.ovpnProxyType,
        onSelected = { onChange(draft.copy(ovpnProxyType = it)) },
        optionLabel = { if (it.isEmpty()) s.noneOption else openVpnProxyLabel(it) }
    )
    Spacer(Modifier.height(4.dp))
    if (draft.ovpnProxyType.isNotBlank()) {
        Row(Modifier.fillMaxWidth()) {
            ExpressiveTextField(
            shape = MaterialTheme.shapes.large,
                value = draft.ovpnProxyServer,
                onValueChange = { onChange(draft.copy(ovpnProxyServer = it)) },
                label = { Text(s.proxyServerLabel) },
                singleLine = true,
                modifier = Modifier.weight(2f).padding(vertical = 4.dp)
            )
            Spacer(Modifier.width(6.dp))
            ExpressiveTextField(
            shape = MaterialTheme.shapes.large,
                value = draft.ovpnProxyPort,
                onValueChange = { onChange(draft.copy(ovpnProxyPort = it.filter { c -> c.isDigit() })) },
                label = { Text(s.portLabel) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f).padding(vertical = 4.dp)
            )
        }
        if (!isObfsProxy(draft.ovpnProxyType)) {
            Field(s.proxyUsernameLabel, draft.ovpnProxyUsername) {
                onChange(draft.copy(ovpnProxyUsername = it))
            }
            Field(s.proxyPasswordLabel, draft.ovpnProxyPassword) {
                onChange(draft.copy(ovpnProxyPassword = it))
            }
        } else {
            Text(
                s.obfsProxyHint,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }

}

/** Drops every obfuscation parameter and turns the node back into plain WireGuard. */
private fun plainWireGuard(d: NodeDraft): NodeDraft = d.copy(
    protocol = "wireguard",
    jc = "", jmin = "", jmax = "",
    s1 = "", s2 = "", s3 = "", s4 = "",
    h1 = "", h2 = "", h3 = "", h4 = "",
    i1 = "", i2 = "", i3 = "", i4 = "", i5 = "",
    j1 = "", j2 = "", j3 = "", itime = "",
    headerProtectionKey = "", contentPaddingAddition = "",
    rekeyAfterTime = "", rekeyTimeout = "", rejectAfterTime = "",
    keepaliveTimeout = "", maxHandshakeAttempts = ""
)

/** Amnezia defaults (Jc/Jmin/Jmax + S1/S2), same values as desktop Lumen and wgtunnel. */
private fun amneziaCompatible(d: NodeDraft): NodeDraft = d.copy(
    protocol = "awg",
    jc = d.jc.ifBlank { "4" },
    jmin = d.jmin.ifBlank { "40" },
    jmax = d.jmax.ifBlank { "70" },
    s1 = d.s1.ifBlank { "0" },
    s2 = d.s2.ifBlank { "0" }
)
