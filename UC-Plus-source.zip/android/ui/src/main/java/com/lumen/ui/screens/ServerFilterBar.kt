package com.lumen.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Width of the right-hand column (tool buttons and sort/ping). Search and protocol share the left column. */
private val ControlsColumnWidth: Dp = 190.dp

/**
 * Search and protocol on the left; refresh, filter and remove-no-ping on the right, with the
 * sort and ping controls beneath them. Search and protocol always have the same width.
 */
@Composable
internal fun ServerFilterBar(
    protocol: String, protocols: List<String>, onProtocol: (String) -> Unit,
    groupByCountry: Boolean, onGroupByCountry: (Boolean) -> Unit,
    reachable: Boolean, onReachable: (Boolean) -> Unit, maxPing: Int, onMaxPing: (Int) -> Unit,
    onReset: () -> Unit, refreshing: Boolean, onRefreshAll: () -> Unit,
    noPingCount: Int = 0, onRemoveNoPing: () -> Unit = {},
    search: @Composable (Modifier) -> Unit = {},
    trailing: @Composable () -> Unit = {}
) {
    val s = LocalStrings.current
    var protocolMenu by remember { mutableStateOf(false) }
    var filterMenu by remember { mutableStateOf(false) }
    val count = (if (groupByCountry) 1 else 0) + (if (reachable) 1 else 0) + (if (maxPing > 0) 1 else 0)
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.Top) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            search(Modifier.fillMaxWidth())
            Box(Modifier.fillMaxWidth()) {
                OutlinedButton({ protocolMenu = true }, Modifier.fillMaxWidth().height(50.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp),
                    shape = com.lumen.ui.components.selectionShape(protocolMenu || protocol.isNotBlank())) {
                    Text(if (protocol.equals("locked", true)) InterfaceText.PROTECTED.inLanguage(s.localeCode)
                        else protocol.ifBlank { s.protocolField }, Modifier.weight(1f), maxLines = 1,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                    Icon(Icons.Default.KeyboardArrowDown, null, Modifier.size(18.dp))
                }
                LumenMenu(protocolMenu, { protocolMenu = false }) {
                    (listOf("" to s.allProtocols) + protocols.map { it to if (it.equals("locked", true))
                        InterfaceText.PROTECTED.inLanguage(s.localeCode) else it.uppercase() }).forEach { (id, label) ->
                        DropdownMenuItem(text = { Text(label) }, trailingIcon = { if (protocol == id) Icon(Icons.Default.Check, null) },
                            onClick = { onProtocol(id); protocolMenu = false })
                    }
                }
            }
        }
        Column(Modifier.width(ControlsColumnWidth), verticalArrangement = Arrangement.spacedBy(6.dp),
            horizontalAlignment = Alignment.End) {
            Row(Modifier.fillMaxWidth().height(50.dp), horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.End),
                verticalAlignment = Alignment.CenterVertically) {
                // Removes only unfavourited servers whose ping test ran and returned no ping (pingMs == 0).
                FilledTonalIconButton(onClick = onRemoveNoPing, enabled = noPingCount > 0 && !refreshing) {
                    BadgedBox(badge = { if (noPingCount > 0) Badge { Text(noPingCount.toString()) } }) {
                        Icon(Icons.Default.DeleteSweep, null)
                    }
                }
                Box {
                    FilledTonalIconButton({ filterMenu = true }) {
                        BadgedBox(badge = { if (count > 0) Badge { Text(count.toString()) } }) {
                            Icon(Icons.Default.FilterList, s.filtersLabel)
                        }
                    }
                    LumenMenu(filterMenu, { filterMenu = false }) {
                        DropdownMenuItem(text = { Text(s.groupByCountry) }, onClick = { onGroupByCountry(!groupByCountry) },
                            trailingIcon = { if (groupByCountry) Icon(Icons.Default.Check, null) })
                        DropdownMenuItem(text = { Text(s.onlyReachable) }, onClick = { onReachable(!reachable) },
                            trailingIcon = { if (reachable) Icon(Icons.Default.Check, null) })
                        HorizontalDivider()
                        listOf(0, 100, 200, 500).forEach { value ->
                            DropdownMenuItem(text = { Text("${s.maxPingLabel}: ${if (value == 0) s.offLabel else "$value ms"}") },
                                onClick = { onMaxPing(value) }, trailingIcon = { if (maxPing == value) Icon(Icons.Default.Check, null) })
                        }
                        DropdownMenuItem(text = { Text(s.resetFilters) }, onClick = { onReset(); filterMenu = false })
                    }
                }
                FilledTonalIconButton(onClick = onRefreshAll, enabled = !refreshing) {
                    Icon(Icons.Default.Refresh, s.refreshSubscription)
                }
            }
            trailing()
        }
    }
}
